################################################################################
#                         T E R M   P R O J E C T                              #
#                             by: HUNTER UMAN                                  #
################################################################################

import pygame
import random

########################## Example Dot Class from ##############################
############ http://blog.lukasperaza.com/getting-started-with-pygame/ ##########
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(Player, self).__init__()
        self.height = 29
        self.width = 5
        self.x, self.y = x, y
        self.xSpeed = 0
        self.ySpeed = 0
        self.rect = pygame.Rect(x - self.width, y - self.height,
                                2 * self.width, 2 * self.height)
        self.image = pygame.Surface((2 * self.width, 2 * self.height),
                                    pygame.SRCALPHA)  # make it transparent
        self.image = self.image.convert_alpha()
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        pygame.draw.rect(self.image, (r,g,b), (x - self.width, y - self.height,
                                2 * self.width, 2 * self.height))
        print('this should draw a rectanlge as in the dot example')

    def getRect(self):  # GET REKT
        self.rect = pygame.Rect(self.x - self.width, self.y - self.height,
                                2 * self.width, 2 * self.height)

    def update(self, screenWidth, screenHeight):
        self.x += self.xSpeed
        self.y += self.ySpeed
        if self.x < 0:
            self.x = screenWidth
        elif self.x > screenWidth:
            self. x = 0
        if self.y < 0:
            self.y = screenHeight
        elif self.y > screenHeight:
            self.y = 0
        self.getRect()

##################### Following OOP Game Structure from ########################
############ http://blog.lukasperaza.com/getting-started-with-pygame/ ##########
class Game(object):

    """
    a bunch of stuff is left out of this file, 
    but you can check it out in the Github repo
    """

    def isKeyPressed(self, key):
        ''' return whether a specific key is being held '''
        return self._keys.get(key, False)

    def __init__(self, width=600, height=400, fps=50, title="gon"):
        self.width = width
        self.height = height
        self.fps = fps
        self.title = title
        pygame.init()

    def init(self):
        pass

    def timerFired(self, dt):
        pass

    def redrawAll(self, screen):
        pass

    def run(self):

        clock = pygame.time.Clock()
        screen = pygame.display.set_mode((self.width, self.height))
        # set the title of the window
        pygame.display.set_caption(self.title)

        # stores all the keys currently being held down
        self._keys = dict()

        # call game-specific initialization
        self.init()
        players = pygame.sprite.Group()
        playing = True
        while playing:
            time = clock.tick(self.fps)
            self.timerFired(time)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    playing = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    p = Player(*event.pos)
                    players.add(p)
                '''
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.mouseReleased(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons == (0, 0, 0)):
                    self.mouseMotion(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons[0] == 1):
                    self.mouseDrag(*(event.pos))
                elif event.type == pygame.KEYDOWN:
                    self._keys[event.key] = True
                    self.keyPressed(event.key, event.mod)
                elif event.type == pygame.KEYUP:
                    self._keys[event.key] = False
                    self.keyReleased(event.key, event.mod)
                '''
            players.update(self.width, self.height)
            screen.fill((255, 255, 255))
            players.draw(screen)
            self.redrawAll(screen)
            pygame.display.flip()

        pygame.quit()

Game().run()
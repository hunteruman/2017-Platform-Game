################################################################################
#                         T E R M   P R O J E C T                              #
#                             by: HUNTER UMAN                                  #
################################################################################

import pygame

class Colour(object):
    darkGray = (75,75,75)
    lightGray = (200,200,200)
    red = (200,75,75)

def getScreen(n):
    if n == 0:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "  Y                           E",
        "                              E",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    elif n == 1 or n == 2:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "Y                             E",
        "                              E",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    elif n == 3:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "Y                             E",
        "                              E",
        "PPPPPPPPPPPPPPPPPPP         PP",
        "PPPPPPPPPPPPPPPPPPP         PP",
        "PPPPPPPPPPPPPPPPPPP         PP",
        "PPPPPPPPPPPPPPPPPPP         PP",
        "EEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"]
    elif n == 4:
        return [
        "   Y                          E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    elif n == 5:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "Y                             E",
        "                              E",
        "PPPPPPPPPPPP    P    P    PPPP",
        "PPPPPPPPPPPP    P    P    PPPP",
        "PPPPPPPPPPPP    P    P    PPPP",
        "PPPPPPPPPPPP    P    P    PPPP",]
    elif n == 6:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "Y                             E",
        "                              E",
        "PPPPPPP    F    F    F    PPPP",
        "PPPPPPP                   PPPP",
        "PPPPPPP                   PPPP",
        "PPPPPPP                   PPPP",]
    elif n == 7:
        return [
        "                              ",
        "                              ",
        "                              ",
        "                              ",
        "                              ",
        "                              ",
        "                              ",
        "                              ",
        "                              ",
        "                          PPPP",
        "                          PPPP",
        "                   F      PPPP",
        "                          PPPP",
        "            F             PPPP",
        "Y                         PPPP",
        "                          PPPP",
        "PPPPPP                    PPPP",
        "PPPPPP                    PPPP",
        "PPPPPP                    PPPP",
        "PPPPPP                    PPPP",
        "EEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"]
    elif n == 8:
        return [
        "   Y                          E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    elif n == 9:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "Y                             E",
        "                              E",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    elif n == 10:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "        F     F     F       PP",
        "Y                           PP",
        "                            PP",
        "PPPP                      PPPP",
        "PPPP                      PPPP",
        "PPPP                      PPPP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]
    elif n == 11:
        return [
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                              E",
        "                            PP",
        "                            PP",
        "                            PP",
        "Y                           PP",
        "                            PP",
        "PP                          PP",
        "PP                          PP",
        "PP                          PP",
        "PPPP                        PP",
        "PPPP                        PP",
        "PPPP                        PP",
        "PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP",]

def buildLevel(game):
    game.screen = getScreen(game.level)
    game.blocks = []
    i = j = 0
    for row in game.screen:
        for col in row:
            if col == 'P':
                p = Block(i, j)
                game.blocks.append(p)
                game.gameObjects.add(p)
            if col == 'E':
                e = ExitBlock(i, j)
                game.blocks.append(e)
                game.gameObjects.add(e)
            if col == 'F':
                f = FallyBlock(i, j)
                game.blocks.append(f)
                game.gameObjects.add(f)
                game.fallyBlocks.add(f)
            if col == 'Y':
                if j == 0:
                    game.player = Player(i,j,0,8)
                else:
                    game.player = Player(i,j)
                game.gameObjects.add(game.player)
            i += 20
        j += 20
        i = 0
        game.newLevel = False

class GameObject(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

class Player(GameObject):
    def __init__(self, x, y, xspeed = 0, yspeed = 0):
        GameObject.__init__(self)
        self.x = x
        self.y = y

        self.right = self.left = self.up = False

        self.xspeed = xspeed
        self.yspeed = yspeed

        self.width = 13
        self.height = 36

        self.dead = False
        self.onBlock = False
        self.grav = True

        self.image = pygame.image.load('images/basicPlayer.png').convert_alpha()
        (a,b,width,height) =  self.image.get_rect()
        self.rect = pygame.Rect(x,y,width,height)

    def update(self, game, blocks):
        if self.left:
            self.xspeed = -4
        if self.right:
            self.xspeed = 4
        if not self.left and not self.right:
            self.xspeed = 0
        if self.up and self.onBlock:
            self.yspeed = -8
        if not self.onBlock:
            self.yspeed += 0.5
            if self.yspeed > 8:
                self.yspeed = 8
        if ((self.rect.left > game.width or self.rect.right < 0) or 
                (self.rect.top > game.height or self.rect.bottom < -50)):
            self.dead = True

        self.rect.left += self.xspeed
        self.collide(self.xspeed, 0, blocks, game)
        self.rect.top += self.yspeed
        self.onBlock = False
        self.collide(0, self.yspeed, blocks, game)

    def collide(self, xspeed, yspeed, blocks, game):
        for block in blocks:
            if pygame.sprite.collide_rect(self, block):
                if isinstance(block, ExitBlock):
                    game.level += 1
                    game.newLevel = True
                if isinstance(block, FallyBlock):
                    block.falling = True
                if xspeed > 0:
                    self.rect.right = block.rect.left
                if xspeed < 0:
                    self.rect.left = block.rect.right
                if yspeed > 0:
                    self.rect.bottom = block.rect.top
                    self.onBlock = True
                    if isinstance(block, FallyBlock):
                        self.yspeed = block.fallSpeed
                    else:
                        self.yspeed = 0
                if yspeed < 0:
                    self.rect.top = block.rect.bottom

class Block(GameObject):
    def __init__(self, x, y):
        GameObject.__init__(self)
        self.image = pygame.Surface((20, 20))
        self.image.fill(Colour.lightGray)
        self.rect = pygame.Rect(x, y, 20, 20)

    def update(self, game, blocks):
        for block in blocks:
            if isinstance(block, FallyBlock):
                if block.falling:
                    block.rect.bottom += block.fallSpeed
                if block.rect.bottom >= game.height:
                    block.remove()
            elif isinstance(block, Pew):
                block.rect.left += block.shootSpeed
                if block.rect.left >= game.width: 
                    block.remove()

class ExitBlock(Block):
    def __init__(self, x, y):
        Block.__init__(self, x, y)
        self.image.fill(Colour.darkGray)

class FallyBlock(Block):
    def __init__(self, x, y):
        Block.__init__(self, x, y)
        self.image.fill(Colour.lightGray)
        self.fallSpeed = 2
        self.falling = False

class Pew(Block):
    def __init__(self, x, y):
        Block.__init__(self, x, y)
        self.image = pygame.Surface((5, 5))
        self.image.fill(Colour.red)
        self.shootSpeed = 10 

################# The following pygame structure is from: ######################
#### https://github.com/LBPeraza/Pygame-Asteroids/blob/master/pygamegame.py ####

'''
pygamegame.py
created by Lukas Peraza
 for 15-112 F15 Pygame Optional Lecture, 11/11/15
use this code in your term project if you want
- CITE IT
- you can modify it to your liking
  - BUT STILL CITE IT
- you should remove the print calls from any function you aren't using
- you might want to move the pygame.display.flip() to your redrawAll function,
    in case you don't need to update the entire display every frame (then you
    should use pygame.display.update(Rect) instead)
'''

class Game(object):

    def init(self):
        self.gameObjects = pygame.sprite.Group()
        self.fallyBlocks = pygame.sprite.Group()
        self.pews = pygame.sprite.Group()
        self.level = 0
        buildLevel(self)

    def mousePressed(self, x, y):
        pass

    def mouseReleased(self, x, y):
        pass

    def mouseMotion(self, x, y):
        pass

    def mouseDrag(self, x, y):
        pass

    def keyPressed(self, keyCode, modifier):
        if keyCode == pygame.K_UP:
            self.player.up = True
        if keyCode == pygame.K_LEFT:
            self.player.left = True
        if keyCode == pygame.K_RIGHT:
            self.player.right = True
        if keyCode == pygame.K_n:
            self.level = (self.level + 1)%12
            self.newLevel = True
        if keyCode == pygame.K_r:
            self.init()
        if keyCode == pygame.K_SPACE:
            p = Pew(self.player.rect.right, (self.player.rect.top +
                    self.player.rect.bottom)/2)
            self.blocks.append(p)
            self.gameObjects.add(p)
            self.fallyBlocks.add(p)

    def keyReleased(self, keyCode, modifier):
        if keyCode == pygame.K_UP:
            self.player.up = False
        if keyCode == pygame.K_LEFT:
            self.player.left = False
        if keyCode == pygame.K_RIGHT:
            self.player.right = False

    def timerFired(self, dt):
        pass

    def redrawAll(self, screen):
        self.gameObjects.draw(screen)

    def isKeyPressed(self, key):
        ''' return whether a specific key is being held '''
        return self._keys.get(key, False)

    def loadNextLevel(self):
        #progresses to the next screen
        self.gameObjects.empty()
        self.fallyBlocks.empty()
        buildLevel(self)

    def __init__(self, width=600, height=400, fps=50, title="gon"):
        self.width = width
        self.height = height
        self.fps = fps
        self.title = title
        self.bgColor = Colour.darkGray
        pygame.init()

    def run(self):

        clock = pygame.time.Clock()
        screen = pygame.display.set_mode((self.width, self.height))
        # set the title of the window
        pygame.display.set_caption(self.title)

        # stores all the keys currently being held down
        self._keys = dict()

        # call game-specific initialization
        self.init()
        playing = True
        while playing:
            time = clock.tick(self.fps)
            self.timerFired(time)
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.mousePressed(*(event.pos))
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.mouseReleased(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons == (0, 0, 0)):
                    self.mouseMotion(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons[0] == 1):
                    self.mouseDrag(*(event.pos))
                elif event.type == pygame.KEYDOWN:
                    self._keys[event.key] = True
                    self.keyPressed(event.key, event.mod)
                elif event.type == pygame.KEYUP:
                    self._keys[event.key] = False
                    self.keyReleased(event.key, event.mod)
                elif event.type == pygame.QUIT:
                    playing = False
            if self.newLevel:
                self.loadNextLevel()
            if self.player.dead:
                self.loadNextLevel()
            screen.fill(self.bgColor)
            self.player.update(self, self.blocks)
            self.fallyBlocks.update(self, self.blocks)
            self.pews.update(self, self.blocks)
            self.redrawAll(screen)
            pygame.display.flip()

        pygame.quit()


def main():
    game = Game()
    game.run()

if __name__ == '__main__':
    main()